<?php
 $yzm =  array (
  'danmuon' => 'on',
  'color' => '#00a1d6',
  'logo' => '/player/img/play_logo.png',
  'trytime' => '99999999999',
  'waittime' => '3',
  'sendtime' => '3',
  'dmrule' => '../dmku/dm_rule.html',
  'pbgjz' => '草,操,妈,逼,滚,网址,网站,支付宝,企,关注,wx,微信,qq,QQ',
  'ads' => 
  array (
    'state' => 'on',
    'pause' => 
    array (
      'pic' => '',
      'link' => '#',
    ),
  ),
);
?>